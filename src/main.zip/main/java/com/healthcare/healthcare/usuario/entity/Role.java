package com.healthcare.healthcare.usuario.entity;

public enum Role {
    ADMIN,
    MEDICO,
    ENFERMERO,
    PACIENTE
}
