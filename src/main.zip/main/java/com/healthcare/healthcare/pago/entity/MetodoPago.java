package com.healthcare.healthcare.pago.entity;

public enum MetodoPago {
    TARJETA,YAPE, ALGO_MAS
}
